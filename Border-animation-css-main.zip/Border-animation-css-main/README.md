# Border-animation-css

screenshot 👇👇👇

![Border Animation](https://user-images.githubusercontent.com/95895380/145509632-a1dd6609-ed8e-4881-b6aa-97617e413eb1.png)

Full Video 👇👇👇

https://youtu.be/wqb0kaRdyyA
